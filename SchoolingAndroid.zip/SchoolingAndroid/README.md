# Schooling - Android project

WebView wrapper around the Schooling PWA. The web app is bundled offline in app/src/main/assets.

## Build the APK
1. Install Android Studio (Hedgehog or newer) and open this folder.
2. Let Gradle sync (it downloads Gradle, the Android Gradle Plugin and the SDK).
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
   Output: app/build/outputs/apk/debug/app-debug.apk

Command line (with Gradle installed): gradle assembleDebug

## Updating the web app
Replace app/src/main/assets/index.html (keep sw.js as is: it is a no-op inside the app).

## Native features added
- File pickers (type=file), alert/confirm/prompt dialogs
- Downloads/exports saved to the Downloads folder
- Print / Save as PDF, popup windows
- WhatsApp / SMS / tel / mailto links open the matching app
- Requires Android 10+ (minSdk 29)

## Security (login)
- Super Admin code check uses a salted, iterated SHA-256 hash (no plain code or weak hash in the file).
- 5 wrong attempts => lock (30s, doubling up to 15 min). Admin sessions auto-lock after 10 min idle / 5 min in background.
- NOTE: any client-side check can only slow attackers down. For real protection use Firebase login (LOCK_ON=true) and a longer code.

## SMS from SIM
First SMS asks for the SMS permission once; after that messages go straight from the default SIM.
(Sideload only: Google Play restricts SEND_SMS.)
