package com.schooling.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.telephony.SmsManager;
import android.util.Base64;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + HOST + "/assets/index.html";

    // Runs on every page: saves blob downloads natively and routes window.print() to Android.
    private static final String HOOK_JS =
            "(function(){if(window.__ab)return;window.__ab=1;"
          + "var oc=HTMLAnchorElement.prototype.click;"
          + "HTMLAnchorElement.prototype.click=function(){var a=this;"
          + "if(a.download&&String(a.href).indexOf('blob:')===0){"
          + "fetch(a.href).then(function(r){return r.blob()}).then(function(b){"
          + "var f=new FileReader();f.onloadend=function(){"
          + "AndroidBridge.saveFile(String(f.result).split(',')[1]||'',b.type||'application/octet-stream',a.download)};"
          + "f.readAsDataURL(b)});return;}"
          + "return oc.call(this);};"
          + "window.print=function(){AndroidBridge.print()};})();";

    private WebView web;
    private WebViewAssetLoader loader;
    private ValueCallback<Uri[]> fileCallback;
    private ActivityResultLauncher<Intent> fileLauncher;
    private ActivityResultLauncher<String> smsPermLauncher;
    private final ArrayList<String[]> pendingSms = new ArrayList<>();
    private WebView printView;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        fileLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(result.getResultCode(), result.getData()));
                fileCallback = null;
            }
        });

        smsPermLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            ArrayList<String[]> q = new ArrayList<>(pendingSms);
            pendingSms.clear();
            for (String[] m : q) {
                if (granted) sendSmsNow(m[0], m[1]);
                else composeSms(m[0], m[1]);
            }
        });

        web = new WebView(this);
        setContentView(web, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        configure(web, false, null);
        web.addJavascriptInterface(new Bridge(web), "AndroidBridge");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (web.canGoBack()) web.goBack();
                else finish();
            }
        });

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(HOME);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configure(WebView w, boolean popup, Dialog dialog) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);

        w.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (HOST.equals(u.getHost()) || scheme.equals("about")
                        || scheme.equals("blob") || scheme.equals("data")) {
                    return false;
                }
                if (scheme.equals("sms") || scheme.equals("smsto") || scheme.equals("mms") || scheme.equals("mmsto")) {
                    handleSms(u);
                    if (popup && dialog != null) dialog.dismiss();
                    return true;
                }
                openExternal(u);
                if (popup && dialog != null) dialog.dismiss();
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript(HOOK_JS, null);
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    fileLauncher.launch(params.createIntent());
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean userGesture, Message resultMsg) {
                showPopup(resultMsg);
                return true;
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String msg, JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, i) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, i) -> r.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, i) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView v, String url, String msg, String def, JsPromptResult r) {
                EditText input = new EditText(MainActivity.this);
                input.setText(def == null ? "" : def);
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(msg)
                        .setView(input)
                        .setPositiveButton(android.R.string.ok, (d, i) -> r.confirm(input.getText().toString()))
                        .setNegativeButton(android.R.string.cancel, (d, i) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel())
                        .show();
                return true;
            }
        });
    }

    /** window.open() support: a full-screen dialog with Print/Close buttons. */
    @SuppressLint("SetJavaScriptEnabled")
    private void showPopup(Message resultMsg) {
        Dialog dialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar);
        WebView pw = new WebView(this);
        configure(pw, true, dialog);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.END);
        Button print = new Button(this);
        print.setText("Print / Save PDF");
        print.setOnClickListener(v -> printWebView(pw));
        Button close = new Button(this);
        close.setText("Close");
        close.setOnClickListener(v -> dialog.dismiss());
        bar.addView(print);
        bar.addView(close);

        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(pw, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        dialog.setContentView(root);
        dialog.setOnDismissListener(d -> pw.destroy());
        dialog.show();

        WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
        transport.setWebView(pw);
        resultMsg.sendToTarget();
    }

    /** sms:<number>?body=<text> -> sent straight from the phone's SIM (asks permission once). */
    private void handleSms(Uri u) {
        String ssp = u.getEncodedSchemeSpecificPart();
        String num = ssp == null ? "" : ssp;
        String body = "";
        int q = num.indexOf('?');
        if (q >= 0) {
            String qs = num.substring(q + 1);
            num = num.substring(0, q);
            String b = Uri.parse("x://h?" + qs).getQueryParameter("body");
            if (b != null) body = b;
        }
        num = Uri.decode(num).replaceAll("[^+\\d]", "");
        if (num.isEmpty()) {
            Toast.makeText(this, "Phone number missing", Toast.LENGTH_SHORT).show();
            return;
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            sendSmsNow(num, body);
        } else {
            pendingSms.add(new String[]{num, body});
            smsPermLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    @SuppressWarnings("deprecation")
    private void sendSmsNow(String num, String body) {
        try {
            SmsManager sm = SmsManager.getDefault();
            ArrayList<String> parts = sm.divideMessage(body);
            if (parts.size() > 1) sm.sendMultipartTextMessage(num, null, parts, null, null);
            else sm.sendTextMessage(num, null, body, null, null);
            Toast.makeText(this, "SMS bheja gaya: " + num, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            composeSms(num, body);
        }
    }

    private void composeSms(String num, String body) {
        try {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + num));
            i.putExtra("sms_body", body);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "SMS nahi bhej saka", Toast.LENGTH_SHORT).show();
        }
    }

    private void openExternal(Uri u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception e) {
            Toast.makeText(this, "No app found to open this link", Toast.LENGTH_SHORT).show();
        }
    }

    private void printWebView(WebView w) {
        PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
        pm.print("Schooling", w.createPrintDocumentAdapter("Schooling"),
                new PrintAttributes.Builder().build());
    }

    /** Methods called from JavaScript (window.AndroidBridge). */
    private class Bridge {
        private final WebView target;

        Bridge(WebView target) {
            this.target = target;
        }

        @JavascriptInterface
        public void print() {
            runOnUiThread(() -> printWebView(target));
        }

        /** Prints an HTML document natively (Android print dialog: Save as PDF / printer). */
        @JavascriptInterface
        public void printHtml(String html, String title) {
            runOnUiThread(() -> {
                final String t = title == null || title.isEmpty() ? "Schooling" : title;
                printView = new WebView(MainActivity.this);
                printView.getSettings().setJavaScriptEnabled(true);
                printView.getSettings().setAllowFileAccess(false);
                printView.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView v, String url) {
                        v.postDelayed(() -> {
                            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                            pm.print(t, v.createPrintDocumentAdapter(t),
                                    new PrintAttributes.Builder()
                                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                        }, 600);
                    }
                });
                printView.loadDataWithBaseURL("https://" + HOST + "/", html, "text/html", "utf-8", null);
            });
        }

        @JavascriptInterface
        public void saveFile(String base64, String mime, String name) {
            try {
                String safe = name == null || name.trim().isEmpty() ? "schooling-export.txt"
                        : name.replaceAll("[\\\\/:*?\"<>|]", "_");
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                cv.put(MediaStore.Downloads.MIME_TYPE, mime == null ? "application/octet-stream" : mime);
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new IllegalStateException("insert failed");
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    os.write(data);
                }
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Saved to Downloads: " + safe, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Could not save file", Toast.LENGTH_LONG).show());
            }
        }
    }
}
